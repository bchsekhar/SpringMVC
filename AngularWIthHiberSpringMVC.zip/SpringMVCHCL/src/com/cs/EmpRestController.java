package com.cs;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmpRestController {
	@Autowired
	SessionFactory sessionFactory;


	@RequestMapping(value = "/getemployee/{empID}", method = RequestMethod.GET,headers="Accept=application/json")
	EmployeeVO search(@PathVariable("empID") int id) {
		EmployeeVO evo1=new EmployeeVO();
		evo1.setEmpName("NodataFound");
		evo1.setDoj(null);
		//Query q=sessionFactory.openSession().createQuery("from EmployeeVO");//where empId=:Idno and mobile=:mob");

		EmployeeVO evo=	(EmployeeVO) sessionFactory.openSession().get(EmployeeVO.class,id);
		if(evo!=null) {
			return evo;
		}
		else {
			return evo1;
		}
	}
	
	
	@RequestMapping(value = "/getALLemployee", method = RequestMethod.GET,headers="Accept=application/json")
	List<EmployeeVO> displayAll() {
		
		Query q=sessionFactory.openSession().createQuery("from EmployeeVO");//where empId=:Idno and mobile=:mob");
return q.list();
		
	}
	
	
	
	
	
}



