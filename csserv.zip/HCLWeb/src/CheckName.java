

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class CheckName
 */
public class CheckName extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name=request.getParameter("uname");
		PrintWriter out=response.getWriter();
		ServletContext application=getServletContext();
		application.setAttribute("nk", name);
		response.sendRedirect("Disp.jsp");
		//request.setAttribute("nk", name);
	//	out.print(name);
		/*HttpSession session=request.getSession();
		session.setMaxInactiveInterval(150);
		session.setAttribute("nk",name);
		response.sendRedirect("Disp.jsp");*/
		//RequestDispatcher rd=request.getRequestDispatcher("Disp.jsp");
		//rd.forward(request,response);
		
		/*Cookie c=new Cookie("nk", name);
		response.addCookie(c);

		Cookie ck[]=request.getCookies();
		PrintWriter out=response.getWriter();
		for(Cookie c1:ck) {


			if(name.equals(c1.getValue())) {

				out.print("Welcome back "+name);
			}
			else {
				out.print("Welcome "+name);

			}


		}
*/
	}}
