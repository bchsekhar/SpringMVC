package com.cs.spring.mvc;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cs.spring.dao.UserDAO;
import com.cs.spring.model.User;
@Controller  
public class TestController { 
	@Autowired
	UserDAO userDAO;
	@RequestMapping("/starts")
	public String display(Model m)
	{
		System.out.println("started");
		m.addAttribute("s", new User());
		return "Login";
	}

	@RequestMapping(value="/login")  
	//public ModelAndView display(@RequestParam("n") String name) 
	public ModelAndView display(@Valid @ModelAttribute("s") User user ,BindingResult result,Model  model) 


	{
		 //model.addAttribute("s", new User()); 
		
		System.out.println("controller"+user.getUserName());
		System.out.println("Date"+user.getDob());
		System.out.println(user.getBranch());
		System.out.println(user.getGen());
		System.out.println(user.getAddress());
		
		ModelAndView mv=null;

	if(result.hasErrors()) {
		mv=new ModelAndView("Login");


	}
	else {

		
		long l=userDAO.regEmployee1(user);
		if(l>0)
		{
			
			mv=new ModelAndView();
			mv.addObject("user", userDAO);
			mv.setViewName("Disp");
		}
		else {
			mv=new ModelAndView();

			mv.addObject("nk", "Bye Mr"+user.getUserName());
			mv.setViewName("index");
		}

	}

	   
	return mv; 

	}



	/*@RequestMapping(value="/login" ,method = RequestMethod.POST)  
	//public ModelAndView display(@RequestParam("n") String name) 
	public ModelAndView display(@ModelAttribute() User user) 


	{
		System.out.println(user.getUserName()+"\t"+user.getPassWord());

		ModelAndView mv=new ModelAndView();
	if(user.getUserName().equals("cs")&& user.getPassWord().equals("cs")) {
		mv.addObject("nk", "Hello   "+user.getUserName()+"   Welcome");
		mv.setViewName("index");
	}
	else {

		mv.addObject("nk", "Bye "+user.getUserName());
		mv.setViewName("index");
	}


	return mv; 
	}     */
}  