package com.cs.spring.dao;



import java.math.BigDecimal;
import java.util.List;

import javax.xml.ws.ServiceMode;



import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.cs.spring.model.User;



@Repository

public class UserDAO {
	@Autowired
	private SessionFactory hibernate4AnnotatedSessionFactory;
	/*
	 * public void setSessionFactory(SessionFactory sessionFactory) {
	 * this.sessionFactory = sessionFactory; }
	 */
	
	Session session;

	@Transactional
	public Long regEmployee1(User user) {
		System.out.println("dao");
		session = hibernate4AnnotatedSessionFactory.getCurrentSession();
		
		Long no = (Long) session.save(user);
		System.out.println("id"+no);
		if (no > 0)
			return no;
		return no;

	}
	/*@Transactional
	public String regEmployee(TrainerInfoVO trainerInfoVO) {
		
		try {
			String name = trainerInfoVO.getTrainerName().substring(0, 3).toUpperCase();
			String sql = "select seq.nextVal from dual";
			Query query = sessionFactory.getCurrentSession().createSQLQuery(sql);
			BigDecimal b = (BigDecimal) query.uniqueResult();
			int id = b.intValue();
			String trainerID = name+id;
			System.out.println(trainerID);
			trainerInfoVO.setTrainerName(trainerID);//setVehicleID(vehicleID);
			sessionFactory.getCurrentSession().save(trainerInfoVO);
			return "Trainer Added Successfully";
		}
		catch(HibernateException e) {
			return "Unable to add Trainer"+e;
		}
	}
	
	

	@Transactional
	public TrainerInfoVO searchTrainer(TrainerInfoVO trainerInfoVO) {
		System.out.println("searchdao");
		session = sessionFactory.getCurrentSession();
		TrainerInfoVO t = (TrainerInfoVO) session.get(TrainerInfoVO.class,
				trainerInfoVO.getMobileNo());
		return t;
	}

	@Transactional
	public String deleteTrainer(TrainerInfoVO trainerInfoVO) {
		String res = null;
		System.out.println("delete dao");
		session = sessionFactory.getCurrentSession();
		TrainerInfoVO t1 = (TrainerInfoVO) session.get(TrainerInfoVO.class,
				trainerInfoVO.getMobileNo());
		if (t1 != null) {
			System.out.println("iffffffffffffffffff");
			session.delete(t1);
			System.out.println("delted");
			res = "success";
		} else {
			res = "fail";
		}
		return res;
	}

	@Transactional
	public List<TrainerInfoVO> viewAll() {
		session = sessionFactory.getCurrentSession();
		@SuppressWarnings("unchecked")
		List<TrainerInfoVO> list = session.createQuery("from TrainerInfoVO")
				.list();

		return list;
	}
	
	@Transactional
	public List<String> viewByTrainer() {
		session = sessionFactory.getCurrentSession();
		Query query= session.createQuery("select trainer.trainerName from TrainerInfoVO trainer order by  trainer.trainerName  ASC");
		@SuppressWarnings("unchecked")
		List<String> list = query.list();
		System.out.println(list.get(0));
		return list;
	}
	
	@Transactional
	public TrainerInfoVO selectTrainer(String trainerName) {
		// TODO Auto-generated method stub
		session = sessionFactory.getCurrentSession();
		
		Query query= session.createQuery("from TrainerInfoVO where trainerName=?");
		query.setString(0,trainerName);
		TrainerInfoVO infoVO=(TrainerInfoVO)query.uniqueResult();
	//	System.out.println("data dao"+infoVO.getEmail()+infoVO.getPlace());
		return infoVO;
	}*/

}
